<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
     <title>ComingSoon</title>
    <meta charset="utf-8" />
    <meta name="description" content="Taarangana'20" />
  <meta name="keywords" content="Taarangana'20" />
  <meta name="author" content="Taarangana'20" />

  <meta property="og:site_name" content="Taarangana'20" />
       
  <meta property="og:description" content="Taarangana'20" />
  <meta property="og:title" content="Taarangana'20" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="http://taarangana.com/" />

  <meta property="twitter:card" content="summary" />
  <meta property="twitter:site" content="@taarangana.com" />
  <meta property="twitter:creator" content="@taarangana.com" />
  <meta property="twitter:url" content="http://taarangana.com/" />
  <!-- <meta property="twitter:image" content="avicon.png" /> -->
  <meta property="twitter:title" content="Taarangana 2020" />
  <meta property="twitter:description" content="Taaranagana'20" />
  <link rel="shortcut icon" href="../favicon1.png">
	 <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/components/button.min.css" />
	 <link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
	 <link href='https://fonts.googleapis.com/css?family=Emilys Candy' rel='stylesheet'>
	 <link href="https://fonts.googleapis.com/css?family=Cute+Font&display=swap" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Vollkorn:400i&display=swap" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Cute+Font&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="comingsoon.css">
	 	
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	
</head>

<body>
<!--<div class="row">
        <div class="col-sm-4">-->
        <?php 
    $color="black";
    include '../navbar.php';
  ?>
    <div style="background:transparent;" class="TEXT">
	   <p style=" font-size: 30px">COMING SOON</p>
	</div>
     <div class="sea">
    <div class="circle-wrapper">
        <div class="bubble"></div>
        <div class="submarine-wrapper">
            <div class="submarine-body">
                <div class="window"></div>
                <div class="engine"></div>
                <div class="light"></div>
            </div>
            <div class="helix"></div>
            <div class="hat">
              <div class="leds-wrapper">
                  <div class="periscope"></div>
                  <div class="leds"></div>
              </div>
            </div>
        </div>
    </div>
</div>


 <script>
        function openNav(x) {

            if ($('#myNav').height() == 0)
                $('#myNav').height('100%');
            else
                $('#myNav').height('0%');

            x.classList.toggle("change");
        }
    </script>



</body>
</html>