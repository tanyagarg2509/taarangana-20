var modalGuessClose = document.getElementById("modal-guess__close");
var modalGuess = document.getElementById("modal-guess");

modalGuessClose.addEventListener("click", function(){
	modalGuess.style.display = "none";
});